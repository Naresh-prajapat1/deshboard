import ComfirmaEmail from "./components/confirmaEmail";
import CreateAccount from "./components/creactAccount";
import Login from "./components/login";
import PasswordReset from "./components/passwordReset";
import RegistrationComplete from "./components/registrationomplete";
import Dashboard from "./components/dashboard";
import MainDashboardHeading from "./components/mainDashboardHeding";
import Orders from "./components/orders";
import DeleteItem from "./components/deleteItem";
function App() {
  return (
    <>
      {/* <Login /> */}
      {/* <CreateAccount /> */}
      {/* <PasswordReset /> */}
      {/* <ComfirmaEmail /> */}
      {/* <RegistrationComplete /> */}
      {/* <Dashboard /> */}
      {/* <Orders /> */}
      <DeleteItem />
    </>
  );
}

export default App;
