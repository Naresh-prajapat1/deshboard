import React from "react";
import styles from "./style.module.css";
import MainDashboardHeading from "../mainDashboardHeding";
const CustomerInfo = () => {
  return (
    <div className={styles.customer_info}>
      <MainDashboardHeading
        title={"Customer Information"}
        fillBtn={true}
        outlineBtn={true}
        title1={"Cancel"}
        title2={"Save"}
        icon={false}
      />
      <div className={styles.ci_wrapper}>
        <div className={styles.ciw_inner}>
          <div className={styles.ciw_userInfo}>
            <div className={styles.ciwu_wrapper}></div>
          </div>
          <div className={styles.ciw_overView}></div>
        </div>
      </div>
    </div>
  );
};
export default CustomerInfo;
